import { Component, OnInit } from '@angular/core';
import { BookServiceService } from '../bookservice.service';
import { IBook } from '../IBook';

@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.css']
})
export class BooksComponent implements OnInit {

  constructor(private bookservice: BookServiceService) { }

  ngOnInit() {
    this.getBookList();
  }

  books: IBook[];
  
  idSearch: number;
  titleSearch: string;
  authorSearch: string;
  yearSearch: number;

  getBookList() {
    this.bookservice.getBookList().subscribe(book => this.books = book);
  }

}
