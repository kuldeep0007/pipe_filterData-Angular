import { Pipe, PipeTransform } from '@angular/core';
import { IBook } from './IBook';
@Pipe({
  name: 'idFilter'
})
export class IdFilterPipe implements PipeTransform {

  str: string;
  transform(books: IBook[], args: string[]): IBook[] {
    if (!books) return [];
    if (!args) return books;
    this.str = args.toString().toLocaleLowerCase();
    return books.filter( book =>
      book.id.toString().toLocaleLowerCase().includes(this.str)
    );
  }

}
