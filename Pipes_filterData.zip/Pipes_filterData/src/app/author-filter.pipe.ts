import { Pipe, PipeTransform } from '@angular/core';
import {IBook} from './IBook';
@Pipe({
  name: 'authorFilter'
})
export class AuthorFilterPipe implements PipeTransform {

str:string;

  transform(books: IBook[], args: string[]): IBook[] {
    if(!books) return null;
    if(!args) return books;

    this.str=args.toString().toLocaleLowerCase();
    return books.filter(book=>
      book.title.toString().toLocaleLowerCase().includes(this.str)
    );
  }

}
