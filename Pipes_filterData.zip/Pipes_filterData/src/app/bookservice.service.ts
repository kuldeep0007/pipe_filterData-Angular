import { Injectable ,OnInit} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { IBook } from './IBook'

@Injectable({
  providedIn: 'root'
})
export class BookServiceService {

  constructor(private http: HttpClient) {
   }

  url='./assets/bookList.json';
  OnInit(){
    this.getBookList();
  }
  
  getBookList():Observable<IBook[]>{
    return this.http.get<IBook[]>(this.url); 
  }


}
